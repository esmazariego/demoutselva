package com.example.demo.dto;
public class Other{
    public DreamWorld dream_world;
    public Home home;
    public OfficialArtwork officialartwork;
}
