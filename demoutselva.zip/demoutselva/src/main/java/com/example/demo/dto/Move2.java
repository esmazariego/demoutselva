package com.example.demo.dto;
public class Move2{
    public String name;
    public String url;
}
