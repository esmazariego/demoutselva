package com.example.demo.dto;
public class MoveLearnMethod{
    public String name;
    public String url;
}
