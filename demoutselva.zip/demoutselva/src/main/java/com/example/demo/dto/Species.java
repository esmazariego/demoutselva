package com.example.demo.dto;
public class Species{
    public String name;
    public String url;
}
