package com.example.demo.dto;
public class Version{
    public String name;
    public String url;
}
