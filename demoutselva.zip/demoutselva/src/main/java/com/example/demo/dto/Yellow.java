package com.example.demo.dto;
public class Yellow{
    public String back_default;
    public String back_gray;
    public String back_transparent;
    public String front_default;
    public String front_gray;
    public String front_transparent;
}
