package com.example.demo.dto;
public class Type{
    public int slot;
    public Type type;
}
