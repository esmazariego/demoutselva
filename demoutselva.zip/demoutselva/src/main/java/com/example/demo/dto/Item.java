package com.example.demo.dto;
public class Item{
    public String name;
    public String url;
}
