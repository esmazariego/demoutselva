package com.example.demo.dto;
public class GenerationVii{
    public Icons icons;
    public UltraSunUltraMoon ultrasunultramoon;
}
