package com.example.demo.dto;
public class Gold{
    public String back_default;
    public String back_shiny;
    public String front_default;
    public String front_shiny;
    public String front_transparent;
}
