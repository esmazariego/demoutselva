package com.example.demo.dto;
public class GenerationVi{
    public OmegarubyAlphasapphire omegarubyalphasapphire;
    public XY xy;
}
