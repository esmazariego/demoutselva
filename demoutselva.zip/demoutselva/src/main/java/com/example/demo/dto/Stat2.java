package com.example.demo.dto;

public class Stat2{
    public String name;
    public String url;
}
