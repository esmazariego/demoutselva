package com.example.demo.dto;
public class GenerationI{
    public RedBlue redblue;
    public Yellow yellow;
}
