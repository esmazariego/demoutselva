package com.example.demo.dto;
public class DreamWorld{
    public String front_default;
    public Object front_female;
}
