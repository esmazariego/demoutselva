package com.example.demo.dto;
public class GenerationV{
    public BlackWhite blackwhite;
}
