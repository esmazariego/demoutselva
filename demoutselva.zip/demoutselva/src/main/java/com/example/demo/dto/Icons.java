package com.example.demo.dto;
public class Icons{
    public String front_default;
    public Object front_female;
}
