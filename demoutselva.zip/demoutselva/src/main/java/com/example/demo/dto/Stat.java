package com.example.demo.dto;

public class Stat{
    public int base_stat;
    public int effort;
    public Stat stat;
}
