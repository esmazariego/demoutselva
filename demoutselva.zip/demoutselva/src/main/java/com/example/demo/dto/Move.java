package com.example.demo.dto;

import java.util.ArrayList;

public class Move{
    public Move move;
    public ArrayList<VersionGroupDetail> version_group_details;
}
