package com.example.demo.dto;
public class Emerald{
    public String front_default;
    public String front_shiny;
}
