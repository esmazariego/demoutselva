package com.example.demo.dto;

public class Versions{
    public GenerationI generationi;
    public GenerationIi generationii;
    public GenerationIii generationiii;
    public GenerationIv generationiv;
    public GenerationV generationv;
    public GenerationVi generationvi;
    public GenerationVii generationvii;
    public GenerationViii generationviii;
}
