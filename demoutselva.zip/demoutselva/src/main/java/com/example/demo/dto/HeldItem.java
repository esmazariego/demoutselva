package com.example.demo.dto;

import java.util.ArrayList;

public class HeldItem{
    public Item item;
    public ArrayList<VersionDetail> version_details;
}
