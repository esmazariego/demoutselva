package com.example.demo.dto;
public class Crystal{
    public String back_default;
    public String back_shiny;
    public String back_shiny_transparent;
    public String back_transparent;
    public String front_default;
    public String front_shiny;
    public String front_shiny_transparent;
    public String front_transparent;
}
