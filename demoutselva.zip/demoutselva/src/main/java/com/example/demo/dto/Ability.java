package com.example.demo.dto;


public class Ability{
    public Ability ability;
    public boolean is_hidden;
    public int slot;
}
