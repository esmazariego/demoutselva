package com.example.demo.dto;
public class GenerationViii{
    public Icons icons;
}
