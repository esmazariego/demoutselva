package com.example.demo.dto;
public class Form{
    public String name;
    public String url;
}
