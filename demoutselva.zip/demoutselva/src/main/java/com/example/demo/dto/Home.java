package com.example.demo.dto;
public class Home{
    public String front_default;
    public String front_female;
    public String front_shiny;
    public String front_shiny_female;
}
