package com.example.demo.dto;
public class OfficialArtwork{
    public String front_default;
}
