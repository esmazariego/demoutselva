
package com.example.demo.dto;
public class GenerationIi{
    public Crystal crystal;
    public Gold gold;
    public Silver silver;
}
