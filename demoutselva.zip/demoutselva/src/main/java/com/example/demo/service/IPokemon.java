package com.example.demo.service;

import com.example.demo.domain.PokemonDomain;

public interface IPokemon {
	
	
	public PokemonDomain getPokemon();

}
