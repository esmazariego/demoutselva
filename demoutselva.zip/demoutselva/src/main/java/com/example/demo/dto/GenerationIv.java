package com.example.demo.dto;
public class GenerationIv{
    public DiamondPearl diamondpearl;
    public HeartgoldSoulsilver heartgoldsoulsilver;
    public Platinum platinum;
}
