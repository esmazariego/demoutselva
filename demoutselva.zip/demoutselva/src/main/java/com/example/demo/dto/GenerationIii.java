package com.example.demo.dto;
public class GenerationIii{
    public Emerald emerald;
    public FireredLeafgreen fireredleafgreen;
    public RubySapphire rubysapphire;
}
