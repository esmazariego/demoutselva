package com.example.demo.dto;
public class VersionGroup{
    public String name;
    public String url;
}
