package com.example.demo.dto;
public class VersionDetail{
    public int rarity;
    public Version version;
}
