package com.example.demo.dto;
public class GameIndex{
    public int game_index;
    public Version version;
}
